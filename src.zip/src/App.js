import React from 'react';
import './App.css';


class Button extends React.Component {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick() {
    this.props.setColor(this.props.index);
    this.props.handleClick(this.props.name, this.props.index);
  }

  render() {
    return (
      <td className="Button" 
          onClick={(e) => this.handleClick()}
          style={{backgroundColor: this.props.color}}>
          {this.props.name}
      </td>
    );
  }

}

class Aside extends React.Component {
  constructor(props) {
    super(props);
    this.setColor = this.setColor.bind(this);
    this.defaultColor = "rgb(207, 117, 43)";
    this.clickColor = "rgb(119, 60, 13)";
    this.state = {colors: [this.clickColor , this.defaultColor, this.defaultColor, this.defaultColor, this.defaultColor]};
  }

  setColor(index) {
    var newColors = [this.defaultColor, this.defaultColor, this.defaultColor, this.defaultColor, this.defaultColor];
    newColors[index] = this.clickColor;
    this.setState({colors: newColors});
  }

  render() {
    return (
      <aside className="Aside">
        <table className="Aside-table">
          <thead>
            <tr><th>Michael Gibbes</th></tr>
          </thead>
          <tbody>
            <tr><Button index={0} color={this.state.colors[0]} name="Home"      handleClick={this.props.onPageChange} setColor={this.setColor}/></tr>
            <tr><Button index={1} color={this.state.colors[1]} name="CS 61A"    handleClick={this.props.onPageChange} setColor={this.setColor}/></tr>
            <tr><Button index={2} color={this.state.colors[2]} name="Portfolio" handleClick={this.props.onPageChange} setColor={this.setColor}/></tr>
            <tr><Button index={3} color={this.state.colors[3]} name="Resume"    handleClick={this.props.onPageChange} setColor={this.setColor}/></tr>
            <tr><Button index={4} color={this.state.colors[4]} name="About"     handleClick={this.props.onPageChange} setColor={this.setColor}/></tr>
          </tbody>
        </table>
      </aside>
    );
  }
}

class Header extends React.Component {
  render() {
    return (
      <header className="Header">
        <h2 className="Header-title">{this.props.header}</h2>
      </header>
    );
  }
}

class Content extends React.Component {
  render() {
    return (
      <article className="Content">
        {this.props.content}
      </article>
    );
  }
}

class App extends React.Component {
  constructor(props) {
    super(props);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.state = {header: "Home", index: 0};
    this.contents = [
      <Content content={<div><p>Welcome to the home page.</p></div>}/>,
      <Content content={<div><p>Congrats for making it through the semester! Y'all are awesome and I'm sure you will succeed.</p></div>}/>,
      <Content content={<div>
        <h3>Particle Smash</h3>
        <p><strong>April 2 2018</strong> - proposal: <a href="https://gibbes.github.io/finalproj-cs184/proposal.html">a three.js framework for realistic and epic destruction</a></p>
        <p><strong>April 23 2018</strong> - milestone: <a href="https://gibbes.github.io/finalproj-cs184/milestone.html">project midpoint project</a></p>
        <p><strong>May 1 2018</strong> - final report: <a href="https://gibbes.github.io/finalproj-cs184/index.html">result of work</a></p>
        <p><a href="https://michael-tu.github.io/cs184-final-project/">Live demo</a></p>
        <h3>Cloth Simulator</h3>
        <p><strong>April 9 2018</strong> - <a href="http://gibby.me/docs/docs4/index.html">capturing the appearance and movement of cloth</a></p>
        <h3>Pathtracer Materials</h3>
        <p><strong>March 19 2018</strong> - <a href="http://gibby.me/docs/docs3_2/index.html">simulating materials in their environments</a></p>
        <p><a href="http://gibby.me/docs/docs3_2/gl/index.html">Cool real-time rendering!</a></p>
        <h3>Pathtracer Functionality</h3>
        <p><strong>March 5 2018</strong> - <a href="http://gibby.me/docs/docs3_1/index.html">casting rays onto a mesh with diffuse materials</a></p>
        <h3>Meshedit</h3>
        <p><strong>February 19 2018</strong> - <a href="http://gibby.me/docs/docs2/index.html">3D geometry and topology methods</a></p>
        <h3>Rasterizer</h3>
        <p><strong>February 5 2018</strong> - <a href="http://gibby.me/docs/docs1/index.html">2D sampling methods</a></p>
      </div>}/>,
      <Content content={<object data={require("./resume.pdf")} type="application/pdf" width="100%" height="800px"><p>Resume</p></object>}/>,
      <Content content={<div><img src={require("./prof.png")} alt="Gibbes"/></div>}/>
    ];
  }

  handlePageChange(header, index) {
    this.setState({header, index});
  }

  render() {
    return (
      <div>
        <Aside onPageChange={this.handlePageChange}/>
        <Header header={this.state.header}/>
        {this.contents[this.state.index]}
      </div>
    );
  }
}

export default App;
